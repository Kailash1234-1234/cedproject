<?php
namespace Ced\Helloworld\Model;
class Likepost extends \Magento\Framework\Model\AbstractModel 
{
	/**
     * Define resource model
     */
	protected function _construct()
	{
		$this->_init('Ced\Helloworld\Model\ResourceModel\Likepost');
	}

	
}
