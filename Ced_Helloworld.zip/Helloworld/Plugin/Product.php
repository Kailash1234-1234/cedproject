<?php
 
// namespace Ced\Helloworld\Plugin;
 
// class Product
// {
//     public function afterGetPrice(\Magento\Catalog\Model\Product $subject, $result)
//     {
//         return $result + ($result*0)/100;
//     }
// }
?>