var config = {
    paths: {
        'owlcarousel': "Ced_Slider/js/owl.carousel"
    },
    shim: {
        'owlcarousel': {
            deps: ['jquery']
        }
    }
};
// var config = {
//     paths: {            
//             'owlcarousel': "Magento_Catalog/js/owlcarousel"
//         },   
//     shim: {
//         'owlcarousel': {
//             deps: ['jquery']
//         }
//     }
// };
